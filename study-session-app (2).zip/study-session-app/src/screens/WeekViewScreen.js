import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  RefreshControl
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { StorageService } from '../services/StorageService';

export default function WeekViewScreen() {
  const [weekData, setWeekData] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadWeekData = async () => {
    const data = await StorageService.getWeekData();
    setWeekData(data);
  };

  useFocusEffect(
    useCallback(() => {
      loadWeekData();
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadWeekData();
    setRefreshing(false);
  };

  const renderDay = (day) => {
    const hasCheckmark = day.completedSessions >= 4;
    
    return (
      <View key={day.date} style={styles.dayCard}>
        <View style={styles.dayHeader}>
          <Text style={styles.dayName}>{day.day}</Text>
          <Text style={styles.dayDate}>{day.date.split('-').slice(1).join('/')}</Text>
        </View>
        <View style={styles.dayContent}>
          <Text style={styles.sessionCount}>
            {day.completedSessions} session{day.completedSessions !== 1 ? 's' : ''}
          </Text>
          {hasCheckmark && (
            <Text style={styles.checkmark}>✓</Text>
          )}
        </View>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill,
              { width: `${Math.min((day.completedSessions / 4) * 100, 100)}%` }
            ]}
          />
        </View>
      </View>
    );
  };

  if (!weekData) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Week Overview</Text>
          <Text style={styles.headerSubtitle}>
            Week starting: {weekData.weekStart}
          </Text>
        </View>

        <View style={styles.examCard}>
          <Text style={styles.examTitle}>📅 Upcoming Exam</Text>
          <Text style={styles.examSubject}>{weekData.examSubject}</Text>
          <Text style={styles.examDate}>{weekData.examDate}</Text>
        </View>

        <View style={styles.legend}>
          <Text style={styles.legendTitle}>Daily Goal:</Text>
          <Text style={styles.legendText}>
            Complete 4 sessions per day to earn a checkmark ✓
          </Text>
        </View>

        <View style={styles.daysContainer}>
          {weekData.days.map(renderDay)}
        </View>

        <View style={styles.summary}>
          <Text style={styles.summaryTitle}>Week Summary</Text>
          <Text style={styles.summaryText}>
            Total Sessions: {weekData.days.reduce((sum, day) => sum + day.completedSessions, 0)}
          </Text>
          <Text style={styles.summaryText}>
            Days with ✓: {weekData.days.filter(day => day.completedSessions >= 4).length} / 7
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  examCard: {
    backgroundColor: '#FFF3E0',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#FF9800',
  },
  examTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#E65100',
    marginBottom: 10,
  },
  examSubject: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  examDate: {
    fontSize: 16,
    color: '#666',
  },
  legend: {
    backgroundColor: '#E3F2FD',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  legendTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1976D2',
    marginBottom: 5,
  },
  legendText: {
    fontSize: 14,
    color: '#666',
  },
  daysContainer: {
    marginBottom: 20,
  },
  dayCard: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  dayHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  dayName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  dayDate: {
    fontSize: 14,
    color: '#666',
  },
  dayContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sessionCount: {
    fontSize: 16,
    color: '#666',
  },
  checkmark: {
    fontSize: 32,
    color: '#4CAF50',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
  },
  summary: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  summaryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  summaryText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },
});