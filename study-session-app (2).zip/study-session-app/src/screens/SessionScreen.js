import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  SafeAreaView
} from 'react-native';
import { StorageService } from '../services/StorageService';

export default function SessionScreen({ route, navigation }) {
  const { sessionId } = route.params;
  const [session, setSession] = useState(null);
  const [focusRating, setFocusRating] = useState(null);
  const [reflection, setReflection] = useState('');
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    loadSession();
  }, []);

  const loadSession = async () => {
    const sessions = await StorageService.getSessions();
    const currentSession = sessions.find(s => s.id === sessionId);
    if (currentSession) {
      setSession(currentSession);
      setIsActive(currentSession.status === 'active');
      setFocusRating(currentSession.focusRating);
      setReflection(currentSession.reflection || '');
    }
  };

  const handleStartSession = async () => {
    const updatedSession = await StorageService.updateSession(sessionId, {
      status: 'active'
    });
    setSession(updatedSession);
    setIsActive(true);
    Alert.alert('Session Started', 'Good luck with your study session!');
  };

  const handleEndSession = async () => {
    if (!focusRating) {
      Alert.alert('Focus Rating Required', 'Please rate your focus level before ending the session.');
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    
    // Update session
    const updatedSession = await StorageService.updateSession(sessionId, {
      status: 'completed',
      focusRating: focusRating,
      reflection: reflection,
      completedDate: today
    });

    // Add points and increment completed count
    const userData = await StorageService.addPoints(25);

    // Update week data
    await StorageService.incrementDaySession(today);

    setSession(updatedSession);
    setIsActive(false);

    Alert.alert(
      'Session Completed! 🎉',
      `Great work! You earned 25 points.\n\nTotal Points: ${userData.points}\nCompleted Sessions: ${userData.completedSessionsCount}`,
      [
        {
          text: 'OK',
          onPress: () => navigation.goBack()
        }
      ]
    );
  };

  const renderFocusButton = (rating) => (
    <TouchableOpacity
      key={rating}
      style={[
        styles.focusButton,
        focusRating === rating && styles.focusButtonSelected
      ]}
      onPress={() => setFocusRating(rating)}
      disabled={!isActive}
    >
      <Text style={[
        styles.focusButtonText,
        focusRating === rating && styles.focusButtonTextSelected
      ]}>
        {rating}
      </Text>
    </TouchableOpacity>
  );

  if (!session) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  const isCompleted = session.status === 'completed';

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>{session.title}</Text>
          {session.subject && (
            <Text style={styles.subject}>Subject: {session.subject}</Text>
          )}
          <Text style={styles.duration}>Duration: {session.duration}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Steps:</Text>
          {session.steps.map((step, index) => (
            <View key={index} style={styles.stepItem}>
              <Text style={styles.stepNumber}>{index + 1}.</Text>
              <Text style={styles.stepText}>{step}</Text>
            </View>
          ))}
        </View>

        {!isCompleted && (
          <>
            {!isActive ? (
              <TouchableOpacity
                style={styles.startButton}
                onPress={handleStartSession}
              >
                <Text style={styles.startButtonText}>Start Session</Text>
              </TouchableOpacity>
            ) : (
              <>
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Focus Rating (1-5):</Text>
                  <Text style={styles.focusDescription}>
                    How focused were you during this session?
                  </Text>
                  <View style={styles.focusContainer}>
                    {[1, 2, 3, 4, 5].map(renderFocusButton)}
                  </View>
                </View>

                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>Reflection (Optional):</Text>
                  <TextInput
                    style={styles.reflectionInput}
                    placeholder="What did you learn? Any challenges?"
                    multiline
                    numberOfLines={4}
                    value={reflection}
                    onChangeText={setReflection}
                    textAlignVertical="top"
                  />
                </View>

                <TouchableOpacity
                  style={styles.endButton}
                  onPress={handleEndSession}
                >
                  <Text style={styles.endButtonText}>End Session</Text>
                </TouchableOpacity>
              </>
            )}
          </>
        )}

        {isCompleted && (
          <View style={styles.completedSection}>
            <Text style={styles.completedTitle}>✓ Session Completed</Text>
            <Text style={styles.completedDetail}>
              Focus Rating: {'⭐'.repeat(session.focusRating)}
            </Text>
            {session.reflection && (
              <>
                <Text style={styles.completedDetailTitle}>Reflection:</Text>
                <Text style={styles.completedDetail}>{session.reflection}</Text>
              </>
            )}
            <Text style={styles.completedDetail}>
              Completed: {session.completedDate}
            </Text>
            <Text style={styles.pointsEarned}>+25 Points Earned! 🎉</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subject: {
    fontSize: 16,
    color: '#666',
    marginBottom: 5,
  },
  duration: {
    fontSize: 16,
    color: '#2196F3',
    fontWeight: '600',
  },
  section: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  stepItem: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  stepNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2196F3',
    marginRight: 10,
    width: 25,
  },
  stepText: {
    fontSize: 16,
    color: '#666',
    flex: 1,
  },
  startButton: {
    backgroundColor: '#4CAF50',
    padding: 18,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  startButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  focusDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 15,
  },
  focusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  focusButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#E0E0E0',
  },
  focusButtonSelected: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  focusButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
  },
  focusButtonTextSelected: {
    color: '#FFFFFF',
  },
  reflectionInput: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
    minHeight: 100,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  endButton: {
    backgroundColor: '#FF5722',
    padding: 18,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  endButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  completedSection: {
    backgroundColor: '#E8F5E9',
    padding: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  completedTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 15,
    textAlign: 'center',
  },
  completedDetailTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 10,
    marginBottom: 5,
  },
  completedDetail: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  pointsEarned: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF9800',
    textAlign: 'center',
    marginTop: 15,
  },
});