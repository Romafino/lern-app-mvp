import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
  SESSIONS: '@sessions',
  USER_DATA: '@user_data',
  WEEK_DATA: '@week_data'
};

export const StorageService = {
  // User Data (points, completed sessions count)
  async getUserData() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.USER_DATA);
      return data ? JSON.parse(data) : { points: 0, completedSessionsCount: 0 };
    } catch (error) {
      console.error('Error getting user data:', error);
      return { points: 0, completedSessionsCount: 0 };
    }
  },

  async updateUserData(userData) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(userData));
    } catch (error) {
      console.error('Error updating user data:', error);
    }
  },

  async addPoints(points) {
    const userData = await this.getUserData();
    userData.points += points;
    userData.completedSessionsCount += 1;
    await this.updateUserData(userData);
    return userData;
  },

  // Sessions
  async getSessions() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.SESSIONS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error getting sessions:', error);
      return [];
    }
  },

  async saveSessions(sessions) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    } catch (error) {
      console.error('Error saving sessions:', error);
    }
  },

  async updateSession(sessionId, updates) {
    const sessions = await this.getSessions();
    const updatedSessions = sessions.map(session => 
      session.id === sessionId ? { ...session, ...updates } : session
    );
    await this.saveSessions(updatedSessions);
    return updatedSessions.find(s => s.id === sessionId);
  },

  // Week Data
  async getWeekData() {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.WEEK_DATA);
      return data ? JSON.parse(data) : this.getDefaultWeekData();
    } catch (error) {
      console.error('Error getting week data:', error);
      return this.getDefaultWeekData();
    }
  },

  getDefaultWeekData() {
    return {
      weekStart: '2025-10-20',
      days: [
        { date: '2025-10-20', day: 'Mon', completedSessions: 0 },
        { date: '2025-10-21', day: 'Tue', completedSessions: 0 },
        { date: '2025-10-22', day: 'Wed', completedSessions: 0 },
        { date: '2025-10-23', day: 'Thu', completedSessions: 0 },
        { date: '2025-10-24', day: 'Fri', completedSessions: 0 },
        { date: '2025-10-25', day: 'Sat', completedSessions: 0 },
        { date: '2025-10-26', day: 'Sun', completedSessions: 0 }
      ],
      examDate: '2025-10-28',
      examSubject: 'Math'
    };
  },

  async updateWeekData(weekData) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.WEEK_DATA, JSON.stringify(weekData));
    } catch (error) {
      console.error('Error updating week data:', error);
    }
  },

  async incrementDaySession(date) {
    const weekData = await this.getWeekData();
    const dayIndex = weekData.days.findIndex(d => d.date === date);
    if (dayIndex !== -1) {
      weekData.days[dayIndex].completedSessions += 1;
      await this.updateWeekData(weekData);
    }
    return weekData;
  },

  // Utility
  async clearAll() {
    try {
      await AsyncStorage.multiRemove([
        STORAGE_KEYS.SESSIONS,
        STORAGE_KEYS.USER_DATA,
        STORAGE_KEYS.WEEK_DATA
      ]);
    } catch (error) {
      console.error('Error clearing storage:', error);
    }
  }
};