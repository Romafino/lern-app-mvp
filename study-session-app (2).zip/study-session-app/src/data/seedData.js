import { StorageService } from '../services/StorageService';

export const seedSessions = [
  {
    id: '1',
    title: 'Algebra Review',
    subject: 'Math',
    duration: '30-45 min',
    steps: [
      'Review formulas',
      'Practice 5 problems',
      'Check solutions'
    ],
    status: 'pending', // pending, active, completed
    focusRating: null,
    reflection: '',
    completedDate: null
  },
  {
    id: '2',
    title: 'Geometry Practice',
    subject: 'Math',
    duration: '30-45 min',
    steps: [
      'Study theorems',
      'Draw diagrams',
      'Solve practice problems'
    ],
    status: 'pending',
    focusRating: null,
    reflection: '',
    completedDate: null
  },
  {
    id: '3',
    title: 'Calculus Basics',
    subject: 'Math',
    duration: '30-45 min',
    steps: [
      'Watch tutorial video',
      'Take notes',
      'Complete exercises'
    ],
    status: 'pending',
    focusRating: null,
    reflection: '',
    completedDate: null
  },
  {
    id: '4',
    title: 'Quick Review Session',
    subject: null, // Aktivierung mode - no subject required
    duration: '30-45 min',
    steps: [
      'Review previous notes',
      'Identify weak areas',
      'Practice key concepts'
    ],
    status: 'pending',
    focusRating: null,
    reflection: '',
    completedDate: null
  }
];

export async function initializeSeedData() {
  const existingSessions = await StorageService.getSessions();
  
  // Only initialize if no sessions exist
  if (existingSessions.length === 0) {
    await StorageService.saveSessions(seedSessions);
    
    // Initialize user data
    await StorageService.updateUserData({
      points: 0,
      completedSessionsCount: 0
    });
    
    // Initialize week data
    const weekData = StorageService.getDefaultWeekData();
    await StorageService.updateWeekData(weekData);
    
    console.log('Seed data initialized');
  }
}