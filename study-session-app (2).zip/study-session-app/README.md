# Study Session Management App - Iteration 2

A mobile app for managing study sessions with points tracking and offline support.

## How to Run

1. **Install dependencies:**
   ```bash
   npm install
